'use strict';

// Install the Syncro RMM agent on THIS PC for a chosen customer.
//
// Syncro has no API that returns an installer, but its own "Command Line"
// install option is: one installer for the account, run with
//   SyncroSetup.exe --console --customerid <id> [--folderid <id>]
// The technician pastes that installer link once (Settings). The customer id
// comes from the active ticket, so picking a ticket is enough to install the
// agent for the right customer.

const path = require('node:path');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const { spawn, execFile } = require('node:child_process');

// Only ever download an installer from Syncro's own hosts.
const ALLOWED_HOSTS = /(^|\.)(syncromsp\.com|syncrosecure\.com|kabutoservices\.com)$/i;

// The Authenticode publisher the Syncro agent installer must be signed by.
// Syncro signs its agent as "Servably, Inc." (confirmed in the field);
// RepairTech/Syncro/Kaseya kept for older/other builds. The Serv(er)?ably
// pattern tolerates either spelling. If a real install is ever refused for an
// unexpected-but-correct publisher, add it here.
const TRUSTED_SIGNER = /(Serv(?:er)?ably|RepairTech|Syncro|Kaseya)/i;

// Accepts either the bare link or the whole command-line snippet copied from
// Syncro (which contains the link). Returns { ok, url } or { ok:false, message }.
function parseInstallerLink(input) {
  const text = String(input || '').trim();
  if (!text) return { ok: false, message: 'Paste the installer link from Syncro.' };
  const m = /https:\/\/[^\s"'<>)]+/i.exec(text);
  if (!m) return { ok: false, message: 'No https:// link found in what was pasted.' };
  let u;
  try { u = new URL(m[0]); } catch { return { ok: false, message: 'That link is not a valid web address.' }; }
  if (u.protocol !== 'https:' || !ALLOWED_HOSTS.test(u.hostname)) {
    return { ok: false, message: 'That link is not on a Syncro address (' + u.hostname + '). Copy it from Syncro: New Asset, Command Line.' };
  }
  const info = decodeInstaller(u.href);
  return { ok: true, url: u.href, customerId: info ? info.customerId : null };
}

// The token after /dl/rs/ is base64 of "v1-<customerId>-<timestamp>-<accountId>-<folderId>".
// Decoding it tells us which CUSTOMER an installer enrols a machine to, so we can
// (a) file a link against the right customer and (b) refuse to install a link whose
// customer doesn't match the ticket — never silently enrol the wrong customer.
function decodeInstaller(url) {
  try {
    const u = new URL(String(url));
    const seg = (u.pathname.split('/').filter(Boolean).pop() || '');
    if (!seg) return null;
    let b64 = seg.replace(/-/g, '+').replace(/_/g, '/');
    while (b64.length % 4) b64 += '=';
    const decoded = Buffer.from(b64, 'base64').toString('utf8');
    const m = /^v\d+-(\d+)-(\d+)-(\d+)-(\d+)/.exec(decoded);
    if (!m) return null;
    return { customerId: m[1], generatedAt: m[2], accountId: m[3], folderId: m[4], raw: decoded };
  } catch {
    return null;
  }
}

function isId(v) { return /^\d{1,12}$/.test(String(v == null ? '' : v)); }

// Arguments for the installer. Never built from free text: ids are digits only.
function buildArgs(customerId, folderId) {
  if (!isId(customerId)) throw new Error('The ticket has no usable customer id.');
  const args = ['--console', '--customerid', String(customerId)];
  if (folderId != null && String(folderId).trim() !== '') {
    if (!isId(folderId)) throw new Error('Policy folder id must be a number.');
    args.push('--folderid', String(folderId).trim());
  }
  return args;
}

function agentPaths() {
  const pf = [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], 'C:\\Program Files', 'C:\\Program Files (x86)'].filter(Boolean);
  const out = [];
  for (const p of pf) { out.push(path.join(p, 'RepairTech', 'Syncro', 'Syncro.Service.exe')); out.push(path.join(p, 'RepairTech', 'Syncro', 'Syncro.App.Runner.exe')); }
  return out;
}
function isInstalled() {
  for (const p of agentPaths()) { try { if (fs.existsSync(p)) return true; } catch { /* ignore */ } }
  return false;
}

async function download(url, dest, onProgress) {
  const res = await fetch(url, { redirect: 'follow', headers: { 'User-Agent': 'TM-Toolset' } });
  if (!res.ok || !res.body) throw new Error('Syncro refused the download (HTTP ' + res.status + '). The installer link in Settings may be out of date.');
  // A redirect must still land on a Syncro-controlled or signed-storage address over https.
  try { if (new URL(res.url).protocol !== 'https:') throw new Error('insecure'); } catch { throw new Error('The download was redirected somewhere unexpected.'); }
  const total = Number(res.headers.get('content-length')) || 0;
  const out = fs.createWriteStream(dest);
  const reader = res.body.getReader();
  let got = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      got += value.length;
      if (!out.write(Buffer.from(value))) await new Promise((r) => out.once('drain', r));
      if (onProgress && total) onProgress('Downloading the installer… ' + Math.round((got / total) * 100) + '%');
    }
  } finally { await new Promise((r) => out.end(r)); }
  if (got < 100 * 1024) throw new Error('The download was only ' + got + ' bytes, which is not an installer. Check the link in Settings.');
  const head = Buffer.alloc(2);
  const fd = fs.openSync(dest, 'r'); try { fs.readSync(fd, head, 0, 2, 0); } finally { fs.closeSync(fd); }
  if (head.toString('latin1') !== 'MZ') throw new Error('The download is not a Windows program. Use the .exe / Command Line link from Syncro, not the MSI or Mac one.');
  return got;
}

// Authenticode check: the file must carry a valid signature before we run it.
function signature(file) {
  return new Promise((resolve) => {
    const ps = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const script = "$s = Get-AuthenticodeSignature -LiteralPath $env:TM_FILE; $n = ''; if ($s.SignerCertificate) { $n = $s.SignerCertificate.Subject }; Write-Output ($s.Status.ToString() + '|' + $n)";
    execFile(ps, ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, timeout: 30000, env: Object.assign({}, process.env, { TM_FILE: file }) }, (err, stdout) => {
      if (err) { resolve({ status: 'Unknown', signer: '' }); return; }
      const [status, subject] = String(stdout || '').trim().split('|');
      const cn = /CN=("([^"]+)"|[^,]+)/.exec(subject || '');
      resolve({ status: status || 'Unknown', signer: cn ? (cn[2] || cn[1]).trim() : '' });
    });
  });
}

// Download the installer from the saved Syncro link, verify it is validly
// signed by Servably (Syncro), and leave the verified .exe in destDir for the
// technician to run themselves. We do NOT run it silently — the earlier
// --console auto-run only unpacked files without registering the service, so
// handing over the official installer (run interactively) is safer and reliable.
async function prepare({ url, destDir, onProgress, label }) {
  if (process.platform !== 'win32') return { ok: false, message: 'The Syncro agent installer only runs on Windows.' };
  const link = parseInstallerLink(url);
  if (!link.ok) return link;
  await fsp.mkdir(destDir, { recursive: true });
  // Name the file after the customer so the tech can always see who it is for.
  const safe = String(label || '').replace(/[^\w.() -]+/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '').trim();
  const exe = path.join(destDir, safe ? ('Syncro-Agent-' + safe + '.exe') : 'Syncro-Agent-Setup.exe');
  try { fs.unlinkSync(exe); } catch { /* ignore — overwrite any old copy */ }
  try {
    if (onProgress) onProgress('Downloading the installer from Syncro…');
    await download(link.url, exe, onProgress);
    if (onProgress) onProgress('Checking the installer is signed…');
    const sig = await signature(exe);
    if (sig.status !== 'Valid') { try { fs.unlinkSync(exe); } catch {} return { ok: false, message: 'The downloaded installer is not validly signed (' + sig.status + '), so it was discarded.' }; }
    // Defence in depth: a valid signature alone isn't enough — the download
    // follows redirects (Syncro's CDN), so require the publisher to actually be
    // Syncro (Servably). A validly-signed binary from anyone else is refused.
    if (!TRUSTED_SIGNER.test(sig.signer || '')) {
      try { fs.unlinkSync(exe); } catch {}
      return { ok: false, message: 'The installer is validly signed, but by an unexpected publisher (' + (sig.signer || 'unknown') + ') — not Syncro — so it was discarded. If this publisher is correct for your Syncro account, let the developer know to allow it.' };
    }
    return { ok: true, path: exe, signer: sig.signer };
  } catch (e) {
    return { ok: false, message: (e && e.message) || String(e) };
  }
}

// Launch the verified installer interactively (the same as double-clicking it),
// so Syncro's own installer handles the full install and customer assignment.
function launch(exe) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve({ ok: false, message: 'Windows only.' });
    try {
      const child = spawn(exe, [], { detached: true, stdio: 'ignore', windowsHide: false });
      child.unref();
      resolve({ ok: true });
    } catch (e) { resolve({ ok: false, message: (e && e.message) || String(e) }); }
  });
}

module.exports = { parseInstallerLink, decodeInstaller, buildArgs, isInstalled, prepare, launch };
